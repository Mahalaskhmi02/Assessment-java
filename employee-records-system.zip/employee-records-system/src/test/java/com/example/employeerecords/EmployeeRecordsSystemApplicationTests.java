package com.example.employeerecords;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRecordsSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
