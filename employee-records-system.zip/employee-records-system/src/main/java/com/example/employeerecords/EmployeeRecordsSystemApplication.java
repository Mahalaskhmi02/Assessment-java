package com.example.employeerecords;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeRecordsSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeRecordsSystemApplication.class, args);
	}

}
